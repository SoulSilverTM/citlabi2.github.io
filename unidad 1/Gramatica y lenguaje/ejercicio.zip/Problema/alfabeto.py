import string #cadena de plantilla
def listAlphabet(): #Almacenamiento de información
    return list(string.ascii_lowercase)


print(listAlphabet())