import string #cadena de plantilla
def listAlphabet(): #Almacenamiento de información
    return [chr(i) for i in range(ord("a"), ord("z") + 2)]


print(listAlphabet())